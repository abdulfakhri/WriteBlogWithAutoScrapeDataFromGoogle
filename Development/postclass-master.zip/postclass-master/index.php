<?php
include 'header.php';

echo 'Posted';

include 'footer.php';
