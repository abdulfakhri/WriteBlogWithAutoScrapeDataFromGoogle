<?php
define("servername", "localhost");
define("username", "root");
define("password", "");
define("dbname", "blog3");
