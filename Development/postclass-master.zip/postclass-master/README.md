# Post Class
This is simple class which perform CRUD blog posts operations.

# Guide
You can find the complete guide for this class on these blogs:

* https://www.webcodegeeks.com/php/creating-complete-blog-crud-using-mysql-php/
* https://www.webcodegeeks.com/php/creating-complete-blog-crud-using-mysql-and-php-part2/